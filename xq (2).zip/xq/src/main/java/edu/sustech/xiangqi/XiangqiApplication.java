package edu.sustech.xiangqi;


import edu.sustech.xiangqi.ui.Logeframe;

import javax.swing.*;

import java.io.*;

public class XiangqiApplication {
    public static void main(String[] args) {
        File file = new File("username");
        SwingUtilities.invokeLater(() -> {
            Logeframe logeframe = new Logeframe("登录/注册");
        });}}






            /*JFrame Logeframe = new JFrame("ahhh");
            Logeframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Logeframe.setLayout(null);
            Logeframe.setSize(800, 700);
            Logeframe.setLocationRelativeTo(null);


            JTextField Namefield = new JTextField();
            Namefield.setLocation(300, 300);
            Namefield.setSize(200, 30);

            JPasswordField PassWordfield = new JPasswordField();
            PassWordfield.setLocation(300, 400);
            PassWordfield.setSize(200, 30);

            JButton button1 = new JButton("注册");
            button1.setLocation(250, 500);
            button1.setSize(100, 40);

            JButton button2 = new JButton("登录");
            button2.setLocation(450, 500);
            button2.setSize(100, 40);

            Logeframe.add(button1);
            Logeframe.add(button2);
            Logeframe.add(Namefield);
            Logeframe.add(PassWordfield);


            JLabel label1 = new JLabel("用户名:");
            label1.setSize(80, 30);
            label1.setLocation(220, 300);
            Logeframe.add(label1);

            JLabel label2 = new JLabel("密码:");
            label2.setSize(80, 30);
            label2.setLocation(220, 400);
            Logeframe.add(label2);


            JLabel label3 = new JLabel("用户名或密码错误");
            label3.setSize(150, 30);
            label3.setLocation(320, 450);
            label3.setVisible(false);
            Logeframe.add(label3);

            JLabel label4 = new JLabel("用户名重复");
            label4.setSize(100, 30);
            label4.setLocation(350, 450);
            label4.setVisible(false);
            Logeframe.add(label4);

            JLabel label5 = new JLabel("注册成功");
            label5.setSize(100, 30);
            label5.setLocation(350, 250);
            label5.setVisible(false);
            Logeframe.add(label5);

            JLabel labelTitle = new JLabel("中国象棋");
            labelTitle.setSize(200, 50);
            labelTitle.setLocation(300, 100);
            labelTitle.setFont(new Font("宋体", Font.BOLD, 24)); // 标题字体
            Logeframe.add(labelTitle);

            Logeframe.setVisible(true);


            /*注册*/
            /*button1.addActionListener(e -> {

                String Name = Namefield.getText();
                String Password = PassWordfield.getText();
                if(readexam(file,Name)){
                    Write(file,Name,Integer.parseInt(Password));
                    Gameframe.setVisible(true);
                    Logeframe.setVisible(false);
                    label5.setVisible(true);
                }else {
                    label4.setVisible(true);

                }




            });
            /*登录*/
          /*  button2.addActionListener(e -> {

                String Name = Namefield.getText();
                String Password = PassWordfield.getText();

                if (read(file, Name) == Integer.parseInt(Password) ){
                    Gameframe.setVisible(true);
                    Logeframe.setVisible(false);

                } else {
                    label3.setVisible(true);
                }

            });


        });
    }

    public static int read(File file, String name) {

        int element = 0;
        ArrayList<String> St = new ArrayList<>();
        BufferedReader br =null;
        try {

            br = new BufferedReader(new FileReader("username"));
            String line;
            while ((line=br.readLine()) != null) {

                St.add(line);

            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < St.size(); i++) {
                if (St.get(i).contains(name)) {

                    // 正则表达式：匹配name后面的数字（支持整数、小数、正负号）
                    // \\Q...\\E 用于转义name中的特殊字符（如.、*等）
                    String regex = "\\Q" + name + "\\E\\D*?([-+]?\\d+\\.?\\d*)";
                    Pattern pattern = Pattern.compile(regex);
                    Matcher matcher = pattern.matcher(St.get(i));

                    if (matcher.find()) {
                        // 提取数字并转换为int
                        try {
                            element=Integer.parseInt(matcher.group(1));
                            break; // 找到第一个匹配后退出（如果需要所有匹配可改为循环）
                        } catch (NumberFormatException e) {
                            System.out.println("无法转换为数字: " + matcher.group(1));
                        }
                    }
                }

            }

        return element;
        }



        public static void Write(File file,String name,int Password){

        try {
            FileWriter Wr = new FileWriter(file,true);
                Wr.write(name +" "+Password);
                Wr.write("\n");
         
            Wr.flush();
            Wr.close();

        } catch (IOException e) {
            System.out.println("error");
        }
    }
    public static boolean readexam(File file, String name) {
        Scanner in;

        ArrayList<String> St = new ArrayList<>();

        try {
            int element = 0;
            ArrayList<String> AAA = new ArrayList<>();
            BufferedReader br =null;
            try {

                br = new BufferedReader(new FileReader("username"));
                String line;
                while ((line=br.readLine()) != null) {

                    AAA.add(line);

                }
                br.close();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }




            for (String s:AAA) {
                if(s.contains(name)){
                    return false;
                }
            }
            br.close();
            return true;



        } catch (FileNotFoundException e) {
            System.out.println("File not found");
               return false;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }



    }
*/