package edu.sustech.xiangqi.model;

import java.util.List;

/**
 * 帅/将
 */
public class GeneralPiece extends AbstractPiece {

    public GeneralPiece(String name, int row, int col, boolean isRed,boolean isALive) {
        super(name, row, col, isRed,isALive);}
    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        // TODO: 实现将/帅的移动规则

        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }
        List<AbstractPiece> allPieces = model.getPieces();


        int rowDiff = targetRow - currentRow;
        int colDiff = targetCol - currentCol;


        if (isRed()) {

            boolean atup = currentRow == 7;
            boolean atleft = currentCol == 3;
            boolean atright = currentCol == 5;
            boolean atdown = (currentRow == 9);

            if (allPieces == null) {
                return false;
            }

            for (AbstractPiece piece : allPieces) {
                // 找到目标位置的棋子
                if (piece.getCol() == targetCol && piece.getRow() == targetRow) {
                    return !piece.isRed();
                }
            }

            if (atleft) {
                //左边界只能向右走
                if (atup) {
                    //上边界只能向下走
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);
                } else if (atdown) {
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == 1;

                }

            }
            // return rowDiff == -1 && colDiff == 0;
            else if (atright) {

                if (atup) {

                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);
                } else if (atdown) {
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;
                }

            } else {
                if (atup) {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else if (atdown) {
                    if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == (-1)) {
                        return true;
                    } else return rowDiff == (-1) && colDiff == 0;
                }
            }

        } else {
            boolean atup = currentRow == 2;
            boolean atleft = currentCol == 3;
            boolean atright = currentCol == 5;
            boolean atdown = currentRow == 0;
            if (atleft) {
                //左边界只能向右走
                if (atup) {
                    //上边界只能向下走
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);//
                } else if (atdown) {
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == 1;

                }

            }
            // return rowDiff == -1 && colDiff == 0;
            else if (atright) {

                if (atup) {

                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);//
                } else if (atdown) {
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;
                }

            } else {
                if (atup) {
                    if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else if (atdown) {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else {

                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == (-1) && colDiff == 0) || (rowDiff == 0 && colDiff == (-1)) || (rowDiff == 0 && colDiff == 1);

                }
            }
        }

    }
}



