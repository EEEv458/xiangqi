package edu.sustech.xiangqi.model;

import java.util.List;

public class shi extends AbstractPiece {

    public shi(String name, int row, int col, boolean isRed, boolean isALive) {
        super(name, row, col, isRed, isALive);
    }

    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }

        if (!isInPalace(targetRow, targetCol)) {
            return false;
        }

        int rowDiffAbs = Math.abs(targetRow - currentRow);
        int colDiffAbs = Math.abs(targetCol - currentCol);
        if (rowDiffAbs != 1 || colDiffAbs != 1) {
            return false;
        }

        List<AbstractPiece> allPieces = model.getPieces();
        if (allPieces == null) {
            throw new IllegalStateException("棋盘棋子列表不能为null！");
        }

        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == targetRow && piece.getCol() == targetCol && piece.getALive()) {
                return piece.isRed() != this.isRed();
            }
        }

        return true;
    }

    private boolean isInPalace(int row, int col) {
        if (col < 3 || col > 5) {
            return false;
        }
        return isRed() ? (row >= 7 && row <= 9) : (row >= 0 && row <= 2);
    }
}