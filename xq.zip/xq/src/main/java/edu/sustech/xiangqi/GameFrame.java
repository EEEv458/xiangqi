package edu.sustech.xiangqi;

import edu.sustech.xiangqi.model.ChessBoardModel;
import edu.sustech.xiangqi.ui.ChessBoardPanel;

import javax.swing.*;

import java.io.*;


public class GameFrame extends JFrame {
    public GameFrame(String title){
        File file = new File("username");

        SwingUtilities.invokeLater(() -> {

            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            ChessBoardModel model = new ChessBoardModel();
            ChessBoardPanel boardPanel = new ChessBoardPanel(model);

            this.add(boardPanel);
            this.setSize(800, 700);
            //this.setLocationRelativeTo(null);
//            this.setVisible(false);

        });}
}

