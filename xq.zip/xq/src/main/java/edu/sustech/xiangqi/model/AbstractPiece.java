package edu.sustech.xiangqi.model;

public abstract class AbstractPiece {
    private final String name;
    private final boolean isRed;
    private int row;
    private int col;
    private boolean isALive;

    public AbstractPiece(String name, int row, int col, boolean isRed, boolean isALive) {

        if (row < 0 || row >= ChessBoardModel.getRows() || col < 0 || col >= ChessBoardModel.getCols()) {
            throw new IllegalArgumentException("初始位置(" + row + "," + col + ")不合法！");
        }
        this.name = name;
        this.row = row;
        this.col = col;
        this.isRed = isRed;
        this.isALive = isALive;
    }

    public boolean getALive() {
        return isALive;
    }

    public void setALive(boolean x) {
        this.isALive = x;
    }

    public String getName() {
        return name;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public boolean isRed() {
        return isRed;
    }

    public void moveTo(int newRow, int newCol) {
        this.row = newRow;
        this.col = newCol;
    }

    public abstract boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model);
}