package edu.sustech.xiangqi.model;

import java.util.List;

public class CannonPiece extends AbstractPiece {

    public CannonPiece(String name, int row, int col, boolean isRed, boolean isALive) {
        super(name, row, col, isRed, isALive);
    }

    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }

        if (!model.isValidPosition(targetRow, targetCol)) {
            return false;
        }

        int rowDiff = targetRow - currentRow;
        int colDiff = targetCol - currentCol;
        if (rowDiff != 0 && colDiff != 0) {
            return false;
        }

        List<AbstractPiece> allPieces = model.getPieces();
        if (allPieces == null) {
            throw new IllegalStateException("棋盘棋子列表不能为null！");
        }

        AbstractPiece targetPiece = model.getPieceAt(targetRow, targetCol);
        int obstacleCount = countObstacles(currentRow, currentCol, targetRow, targetCol, model);

        if (targetPiece == null) {
            return obstacleCount == 0;
        } else {
            if (targetPiece.isRed() == this.isRed()) {
                return false;
            }
            return obstacleCount == 1;
        }
    }

    private int countObstacles(int startRow, int startCol, int targetRow, int targetCol, ChessBoardModel model) {
        List<AbstractPiece> allPieces = model.getPieces();
        int count = 0;

        if (startRow == targetRow) {
            int minCol = Math.min(startCol, targetCol);
            int maxCol = Math.max(startCol, targetCol);
            for (int col = minCol + 1; col < maxCol; col++) {
                for (AbstractPiece piece : allPieces) {
                    if (piece.getRow() == startRow && piece.getCol() == col && piece.getALive()) {
                        count++;
                    }
                }
            }
        } else {
            int minRow = Math.min(startRow, targetRow);
            int maxRow = Math.max(startRow, targetRow);
            for (int row = minRow + 1; row < maxRow; row++) {
                for (AbstractPiece piece : allPieces) {
                    if (piece.getRow() == row && piece.getCol() == startCol && piece.getALive()) {
                        count++;
                    }
                }
            }
        }
        return count;
    }
}