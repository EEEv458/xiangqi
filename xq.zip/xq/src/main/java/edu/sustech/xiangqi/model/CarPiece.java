package edu.sustech.xiangqi.model;

import java.util.List;

public class CarPiece extends AbstractPiece {

    public CarPiece(String name, int row, int col, boolean isRed, boolean isALive) {
        super(name, row, col, isRed, isALive);
    }

    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }

        int rowDiff = targetRow - currentRow;
        int colDiff = targetCol - currentCol;
        if (rowDiff != 0 && colDiff != 0) {
            return false;
        }

        if (!isPathClear(currentRow, currentCol, targetRow, targetCol, model)) {
            return false;
        }

        List<AbstractPiece> allPieces = model.getPieces();
        if (allPieces == null) {
            throw new IllegalStateException("棋盘棋子列表不能为null！");
        }

        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == targetRow && piece.getCol() == targetCol && piece.getALive()) {
                return piece.isRed() != this.isRed();
            }
        }

        return true;
    }

    private boolean isPathClear(int startRow, int startCol, int targetRow, int targetCol, ChessBoardModel model) {
        List<AbstractPiece> allPieces = model.getPieces();
        if (allPieces == null) {
            return true;
        }

        if (startRow == targetRow) {
            int minCol = Math.min(startCol, targetCol);
            int maxCol = Math.max(startCol, targetCol);
            for (int col = minCol + 1; col < maxCol; col++) {
                for (AbstractPiece piece : allPieces) {
                    if (piece.getRow() == startRow && piece.getCol() == col && piece.getALive()) {
                        return false;
                    }
                }
            }
        } else {
            int minRow = Math.min(startRow, targetRow);
            int maxRow = Math.max(startRow, targetRow);
            for (int row = minRow + 1; row < maxRow; row++) {
                for (AbstractPiece piece : allPieces) {
                    if (piece.getRow() == row && piece.getCol() == startCol && piece.getALive()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
