package edu.sustech.xiangqi.model;

import java.util.ArrayList;
import java.util.List;

public class ChessBoardModel {
    private final List<AbstractPiece> pieces;
    private static final int ROWS = 10;
    private static final int COLS = 9;
    private final int[][] map = new int[ROWS][COLS];

    public ChessBoardModel() {
        pieces = new ArrayList<>();
        initializePieces();
        Setmap();
    }

    private void initializePieces() {
        pieces.add(new shi("仕", 0, 5, false, true));
        pieces.add(new shi("仕", 0, 3, false, true));
        pieces.add(new GeneralPiece("將", 0, 4, false, true));
        pieces.add(new SoldierPiece("卒", 3, 0, false, true));
        pieces.add(new SoldierPiece("卒", 3, 2, false, true));
        pieces.add(new SoldierPiece("卒", 3, 4, false, true));
        pieces.add(new SoldierPiece("卒", 3, 6, false, true));
        pieces.add(new SoldierPiece("卒", 3, 8, false, true));
        pieces.add(new ElephantPiece("象", 0, 2, false, true));
        pieces.add(new ElephantPiece("象", 0, 6, false, true));
        pieces.add(new HorsePiece("馬", 0, 1, false, true));
        pieces.add(new HorsePiece("馬", 0, 7, false, true));
        pieces.add(new CarPiece("車", 0, 8, false, true));
        pieces.add(new CarPiece("車", 0, 0, false, true));
        pieces.add(new CannonPiece("炮", 2, 1, false, true));
        pieces.add(new CannonPiece("炮", 2, 7, false, true));

        pieces.add(new shi("士", 9, 5, true, true));
        pieces.add(new shi("士", 9, 3, true, true));
        pieces.add(new GeneralPiece("帅", 9, 4, true, true));
        pieces.add(new SoldierPiece("兵", 6, 0, true, true));
        pieces.add(new SoldierPiece("兵", 6, 2, true, true));
        pieces.add(new SoldierPiece("兵", 6, 4, true, true));
        pieces.add(new SoldierPiece("兵", 6, 6, true, true));
        pieces.add(new SoldierPiece("兵", 6, 8, true, true));
        pieces.add(new ElephantPiece("相", 9, 2, true, true));
        pieces.add(new ElephantPiece("相", 9, 6, true, true));
        pieces.add(new HorsePiece("马", 9, 1, true, true));
        pieces.add(new HorsePiece("马", 9, 7, true, true));
        pieces.add(new CarPiece("车", 9, 8, true, true));
        pieces.add(new CarPiece("车", 9, 0, true, true));
        pieces.add(new CannonPiece("炮", 7, 1, true, true));
        pieces.add(new CannonPiece("炮", 7, 7, true, true));
    }

    public List<AbstractPiece> getPieces() {
        return pieces;
    }

    public AbstractPiece getPieceAt(int row, int col) {
        for (AbstractPiece piece : pieces) {
            if (piece.getRow() == row && piece.getCol() == col && piece.getALive()) {
                return piece;
            }
        }
        return null;
    }

    public boolean isValidPosition(int row, int col) {
        return row >= 0 && row < ROWS && col >= 0 && col < COLS;
    }

    public boolean movePiece(AbstractPiece piece, int newRow, int newCol) {
        if (!isValidPosition(newRow, newCol) || !piece.getALive()) {
            return false;
        }

        if (!piece.canMoveTo(newRow, newCol, this)) {
            return false;
        }

        AbstractPiece targetPiece = getPieceAt(newRow, newCol);
        if (targetPiece != null) {
            targetPiece.setALive(false);
            pieces.remove(targetPiece);
        }

        piece.moveTo(newRow, newCol);
        Setmap();
        return true;
    }

    public static int getRows() {
        return ROWS;
    }

    public static int getCols() {
        return COLS;
    }

    public int[][] Setmap() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                map[i][j] = 0;
            }
        }

        for (AbstractPiece piece : pieces) {
            if (piece.getALive()) {
                if (piece.isRed()) {
                    map[piece.getRow()][piece.getCol()] = 1;
                } else {
                    map[piece.getRow()][piece.getCol()] = -1;
                }
            }
        }
        return map;
    }
}