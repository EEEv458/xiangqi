package edu.sustech.xiangqi.model;

import java.util.List;

public class ElephantPiece extends AbstractPiece {

    public ElephantPiece(String name, int row, int col, boolean isRed, boolean isALive) {
        super(name, row, col, isRed, isALive);
    }

    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }

        if (!model.isValidPosition(targetRow, targetCol)) {
            return false;
        }

        if (isRed() && targetRow < 5) {
            return false;
        }
        if (!isRed() && targetRow >= 5) {
            return false;
        }

        int rowDiffAbs = Math.abs(targetRow - currentRow);
        int colDiffAbs = Math.abs(targetCol - currentCol);
        if (rowDiffAbs != 2 || colDiffAbs != 2) {
            return false;
        }

        if (isEyeBlocked(currentRow, currentCol, targetRow, targetCol, model)) {
            return false;
        }

        List<AbstractPiece> allPieces = model.getPieces();
        if (allPieces == null) {
            throw new IllegalStateException("棋盘棋子列表不能为null！");
        }

        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == targetRow && piece.getCol() == targetCol && piece.getALive()) {
                return piece.isRed() != this.isRed();
            }
        }

        return true;
    }

    private boolean isEyeBlocked(int startRow, int startCol, int targetRow, int targetCol, ChessBoardModel model) {
        int eyeRow = startRow + (targetRow - startRow) / 2;
        int eyeCol = startCol + (targetCol - startCol) / 2;

        List<AbstractPiece> allPieces = model.getPieces();
        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == eyeRow && piece.getCol() == eyeCol && piece.getALive()) {
                return true;
            }
        }
        return false;
    }
}