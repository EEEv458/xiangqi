package edu.sustech.xiangqi.model;

import java.util.List;

/**
 * 帅/将
 */
public class GeneralPiece extends AbstractPiece {

    public GeneralPiece(String name, int row, int col, boolean isRed,boolean isALive) {
        super(name, row, col, isRed,isALive);}
    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        // TODO: 实现将/帅的移动规则

        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }

        int rowDiff = targetRow - currentRow;
        int colDiff = targetCol - currentCol;


        if (isRed()) {

            boolean atup = currentRow == 7;
            boolean atleft = currentCol == 3;
            boolean atright = currentCol == 5;
            boolean atdown = (currentRow == 9);
            List<AbstractPiece> allPieces = model.getPieces();
            // 判空：避免 model.getPieces() 返回 null 导致空指针异常
            if (allPieces == null) {
                return false; // 或根据业务返回默认值（如抛出异常）
            }

            for (AbstractPiece piece : allPieces) {
                // 找到目标位置的棋子
                if (piece.getCol() == targetCol && piece.getRow() == targetRow) {
                    // 核心逻辑：只能吃黑方棋子（黑棋返回 true，红棋返回 false）
                    return !piece.isRed();
                }
            }

            // 循环结束仍未找到棋子 → 目标位置为空，可落子


            if (atleft) {
                //左边界只能向右走
                if (atup) {
                    //上边界只能向下走
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);//
                } else if (atdown) {
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == 1;

                }

            }
            // return rowDiff == -1 && colDiff == 0;
            else if (atright) {

                if (atup) {

                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);//
                } else if (atdown) {
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;
                }

            } else {
                if (atup) {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else if (atdown) {
                    if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == (-1)) {
                        return true;
                    } else return rowDiff == (-1) && colDiff == 0;
                }
            }

        } else {
            boolean atup = currentRow == 2;
            boolean atleft = currentCol == 3;
            boolean atright = currentCol == 5;
            boolean atdown = currentRow == 0;
            if (atleft) {
                //左边界只能向右走
                if (atup) {
                    //上边界只能向下走
                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);//
                } else if (atdown) {
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == 1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == 1;

                }

            }
            // return rowDiff == -1 && colDiff == 0;
            else if (atright) {

                if (atup) {

                    return (rowDiff == -1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);//
                } else if (atdown) {
                    return (rowDiff == 1 && colDiff == 0) || (rowDiff == 0 && colDiff == -1);
                } else {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;
                }

            } else {
                if (atup) {
                    if (rowDiff == -1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else if (atdown) {
                    if (rowDiff == 1 && colDiff == 0) {
                        return true;
                    } else if (rowDiff == 0 && colDiff == 1) {
                        return true;
                    } else return rowDiff == 0 && colDiff == -1;

                } else {

                        return (rowDiff == 1 && colDiff == 0)||(rowDiff == (-1) && colDiff == 0)||(rowDiff == 0 && colDiff == (-1))||(rowDiff == 0 && colDiff == 1);

                }
            }
        }

    }
}



