package edu.sustech.xiangqi.model;

import java.util.List;

public class HorsePiece extends AbstractPiece {

    public HorsePiece(String name, int row, int col, boolean isRed, boolean isALive) {
        super(name, row, col, isRed, isALive);
    }

    @Override
    public boolean canMoveTo(int targetRow, int targetCol, ChessBoardModel model) {
        int currentRow = getRow();
        int currentCol = getCol();

        if (currentRow == targetRow && currentCol == targetCol) {
            return false;
        }



        int rowDiffAbs = Math.abs(targetRow - currentRow);
        int colDiffAbs = Math.abs(targetCol - currentCol);
        boolean isDayMove = (rowDiffAbs == 2 && colDiffAbs == 1) || (rowDiffAbs == 1 && colDiffAbs == 2);
        if (!isDayMove) {
            return false;
        }

        if (isLegBlocked(currentRow, currentCol, targetRow, targetCol, model)) {
            return false;
        }

        List<AbstractPiece> allPieces = model.getPieces();


        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == targetRow && piece.getCol() == targetCol && piece.getALive()) {
                return piece.isRed() != this.isRed();
            }
        }

        return true;
    }

    private boolean isLegBlocked(int startRow, int startCol, int targetRow, int targetCol, ChessBoardModel model) {
        int legRow = startRow;
        int legCol = startCol;

        int rowDiff = targetRow - startRow;
        int colDiff = targetCol - startCol;

        if (rowDiff == 2) legRow++;
        if (rowDiff == -2) legRow--;
        if (colDiff == 2) legCol++;
        if (colDiff == -2) legCol--;

        List<AbstractPiece> allPieces = model.getPieces();
        for (AbstractPiece piece : allPieces) {
            if (piece.getRow() == legRow && piece.getCol() == legCol && piece.getALive()) {
                return true;
            }
        }
        return false;
    }
}